console.log('[LeetCode Analyzer] Loading content script...');

// Function to inject our analyzer script into the page
const injectAnalyzer = () => {
  // Create a new script element
  const script = document.createElement('script');
  // Set the source to our inject.js file
  script.src = chrome.runtime.getURL('inject.js');
  // Remove the script element after it loads
  script.onload = () => script.remove();
  // Add the script to the page
  (document.head || document.documentElement).appendChild(script);
};

// Wait for LeetCode's app container to be available
const waitForLeetCodeApp = () => {
  const maxAttempts = 15;
  let attempts = 0;

  const checkApp = () => {
    // Check if the app container exists or we've tried too many times
    if (document.getElementById('app') || attempts >= maxAttempts) {
      // Inject our analyzer and initialize the UI
      injectAnalyzer();
      initializeUI();
    } else {
      // Try again after a short delay
      attempts++;
      setTimeout(checkApp, 500);
    }
  };

  checkApp();
};

// Initialize the UI elements
function initializeUI() {
  // Only create the UI if it doesn't already exist
  if (!document.querySelector('.leetcode-analyzer-ui')) {
    const container = document.createElement('div');
    container.className = 'leetcode-analyzer-ui';
    container.innerHTML = `
      <style>
        /* Styling for the analysis panel */
        .leetcode-analyzer-ui {
          position: fixed;
          top: 20px;
          right: 20px;
          width: 300px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
          padding: 15px;
          z-index: 1000;
          max-height: 80vh;
          overflow-y: auto;
        }

        .leetcode-analyzer-ui h3 {
          margin: 0 0 10px 0;
          color: #333;
          font-size: 16px;
        }

        .analysis-content {
          font-size: 14px;
          line-height: 1.5;
          color: #444;
        }

        /* Highlight style for code lines mentioned in analysis */
        .leetcode-analyzer-highlight {
          background-color: rgba(255, 255, 0, 0.2);
          transition: background-color 0.3s ease;
        }
      </style>
      <h3>Code Analysis</h3>
      <div class="analysis-content">
        <p>Start typing to see analysis...</p>
      </div>
    `;
    document.body.appendChild(container);
  }
}

// Listen for code changes from the injected script
window.addEventListener('leetCodeEditorChanged', async (event) => {
  const { code, problemSlug } = event.detail;
  await analyzeCode(code, problemSlug);
});

// Main function to analyze the code
async function analyzeCode(code, problemSlug) {
  if (!code || !problemSlug) return;

  const container = document.querySelector('.leetcode-analyzer-ui');
  if (!container) return;

  try {
    const analysisContent = container.querySelector('.analysis-content');
    analysisContent.innerHTML = '<p>Analyzing code...</p>';

    // Get the API key from Chrome's storage
    const { openaiKey } = await chrome.storage.sync.get('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');
    
    if (!openaiKey) {
      throw new Error('Please set your OpenAI API key in the extension options');
    }

    const analysis = await analyzeCodeWithOpenAI(code, problemSlug);
    displayAnalysisResults(analysis);
  } catch (error) {
    console.error('Error analyzing code:', error);
    const analysisContent = container.querySelector('.analysis-content');
    
    // Show more specific error messages
    if (error.message.includes('API key')) {
      analysisContent.innerHTML = `
        <p style="color: red;">${error.message}</p>
        <p>Please right-click the extension icon and select "Options" to set your API key.</p>
      `;
    } else if (error.message.includes('Failed to analyze')) {
      analysisContent.innerHTML = `
        <p style="color: red;">Failed to analyze code. Please check your internet connection and try again.</p>
        <p>Error details: ${error.message}</p>
      `;
    } else {
      analysisContent.innerHTML = `
        <p style="color: red;">Error analyzing code: ${error.message}</p>
        <p>Please try again later.</p>
      `;
    }
  }
}

// Function to call OpenAI's API for code analysis
async function analyzeCodeWithOpenAI(code, problemSlug) {
  // Make the API call to OpenAI
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${openaiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are a code analysis assistant. Analyze the provided code for potential issues, optimizations, and best practices. Be concise and focus on the most important points.'
        },
        {
          role: 'user',
          content: `Analyze this code for LeetCode problem ${problemSlug}:\n\n${code}`
        }
      ]
    })
  });

  if (!response.ok) {
    throw new Error('Failed to analyze code');
  }

  const data = await response.json();
  return {
    analysis: data.choices[0].message.content,
    lines: extractLinesFromAnalysis(data.choices[0].message.content)
  };
}

// Extract line numbers mentioned in the analysis
function extractLinesFromAnalysis(analysis) {
  const lines = [];
  const lineRegex = /line (\d+)/gi;
  let match;
  
  // Find all line number references in the analysis
  while ((match = lineRegex.exec(analysis)) !== null) {
    lines.push(parseInt(match[1]));
  }
  
  // Remove duplicate line numbers
  return [...new Set(lines)];
}

// Display the analysis results in the UI
function displayAnalysisResults(results) {
  const container = document.querySelector('.leetcode-analyzer-ui');
  if (!container) return;

  const analysisContent = container.querySelector('.analysis-content');
  // Convert newlines to HTML line breaks
  analysisContent.innerHTML = `
    <div class="analysis-text">
      ${results.analysis.replace(/\n/g, '<br>')}
    </div>
  `;

  // Highlight the relevant code lines
  highlightCodeLines(results.lines);
}

// Highlight specific lines in the code editor
function highlightCodeLines(lines) {
  const codeLines = document.querySelectorAll('.view-line');
  codeLines.forEach((line, index) => {
    if (lines.includes(index + 1)) {
      line.classList.add('leetcode-analyzer-highlight');
    } else {
      line.classList.remove('leetcode-analyzer-highlight');
    }
  });
}

// Start the extension
waitForLeetCodeApp();