console.log('[LeetCode Analyzer] Injected script loaded');

// Debounce function to limit how often we trigger analysis
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        // Clear the previous timeout
        clearTimeout(timeout);
        // Set a new timeout
        timeout = setTimeout(() => {
            console.log('[LeetCode Analyzer] Debounced function triggered after', wait, 'ms of inactivity');
            func(...args);
        }, wait);
    };
}

// Wait for Monaco editor to be available
function waitForMonaco(callback) {
    console.log('[LeetCode Analyzer] Waiting for Monaco editor...');
    const interval = setInterval(() => {
        if (window.monaco) {
            console.log('[LeetCode Analyzer] Monaco editor found');
            clearInterval(interval);
            callback();
        }
    }, 100);
}

// Initialize the analyzer
waitForMonaco(() => {
    const editor = window.monaco.editor.getModels()[0];
    if (!editor) {
        console.error('[LeetCode Analyzer] Could not find editor model');
        return;
    }

    console.log('[LeetCode Analyzer] Setting up content change listener');

    // Create a debounced version of the content change handler
    const debouncedContentChange = debounce(() => {
        const code = editor.getValue();
        // Get the problem slug from the URL (e.g., "two-sum" from "leetcode.com/problems/two-sum")
        const problemSlug = window.location.pathname.split('/')[2];
        
        console.log('[LeetCode Analyzer] Code changed, dispatching event with problem slug:', problemSlug);
        
        // Dispatch a custom event that content.js can listen to
        window.dispatchEvent(new CustomEvent('leetCodeEditorChanged', {
            detail: {
                code: code,
                problemSlug: problemSlug
            }
        }));
    }, 5000); // Wait 5 seconds after the last keystroke

    // Listen for content changes and use the debounced handler
    editor.onDidChangeContent(debouncedContentChange);

    console.log('[LeetCode Analyzer] Monaco editor hooks initialized');
});
