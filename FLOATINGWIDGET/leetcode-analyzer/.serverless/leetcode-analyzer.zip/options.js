document.addEventListener('DOMContentLoaded', () => {
    // Load saved API key
    chrome.storage.sync.get('openaiKey', (data) => {
        if (data.openaiKey) {
            document.getElementById('openai-key').value = data.openaiKey;
        }
    });

    // Save API key
    document.getElementById('save').addEventListener('click', () => {
        const openaiKey = document.getElementById('openai-key').value.trim();
        
        if (!openaiKey) {
            showStatus('Please enter an API key', false);
            return;
        }

        chrome.storage.sync.set({ openaiKey }, () => {
            showStatus('API key saved successfully!', true);
        });
    });
});

function showStatus(message, success) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = 'status ' + (success ? 'success' : 'error');
    status.style.display = 'block';

    setTimeout(() => {
        status.style.display = 'none';
    }, 3000);
} 