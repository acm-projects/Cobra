/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./src/error-analysis/codeAnalysis.js ***!
  \********************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   analyzeCode: () => (/* binding */ analyzeCode),
/* harmony export */   formatAnalysisResults: () => (/* binding */ formatAnalysisResults)
/* harmony export */ });
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
// Code Analysis Module
// This module handles analyzing code for errors, performance issues, and other problems

// Define error types
var ErrorType = {
  ERROR: 'error',
  WARNING: 'warning',
  PERFORMANCE: 'performance',
  SUGGESTION: 'suggestion'
};

// Simple text-based patterns to identify common coding issues
var COMMON_PATTERNS = [{
  pattern: /while\s*\([^;]*\)\s*\{\s*[^;]*\}/,
  message: 'Potential infinite loop detected. Ensure the loop condition will eventually be false.',
  type: ErrorType.ERROR,
  fix: 'Make sure you increment your counter variable inside the loop.'
}, {
  pattern: /for\s*\([^;]*;\s*[^;]*;\s*\)\s*\{/,
  message: 'Missing loop increment in for loop, which may cause an infinite loop.',
  type: ErrorType.ERROR,
  fix: 'Add an increment statement in the third part of the for loop, e.g., for(i=0; i<10; i++)'
}, {
  pattern: /if\s*\([^=]*=[^=][^)]*\)/,
  message: 'Assignment (=) used in conditional instead of comparison (== or ===).',
  type: ErrorType.ERROR,
  fix: 'Change = to === for strict equality comparison or == for loose equality.'
}, {
  pattern: /==/,
  message: 'Using loose equality (==) which may lead to unexpected type coercion.',
  type: ErrorType.WARNING,
  fix: 'Consider using strict equality (===) to avoid type coercion issues.'
}, {
  pattern: /Array\.sort\(\)/,
  message: 'Array.sort() without a compare function sorts elements as strings by default.',
  type: ErrorType.WARNING,
  fix: 'Provide a compare function, e.g., Array.sort((a, b) => a - b) for numeric sorting.'
}, {
  pattern: /\w+\.\w+\s*===?\s*undefined/,
  message: 'Potential TypeError if the parent object is undefined.',
  type: ErrorType.WARNING,
  fix: 'Use optional chaining operator (?.) or check if the parent exists first.'
}, {
  pattern: /O\(n\^2\)/i,
  message: 'Quadratic time complexity detected. This may be inefficient for large inputs.',
  type: ErrorType.PERFORMANCE,
  fix: 'Consider a more efficient algorithm or data structure.'
}, {
  pattern: /\.indexOf\([^)]*\)\s*!=?=?\s*-1/,
  message: 'Using indexOf for existence check is less readable than includes() and can be slower.',
  type: ErrorType.PERFORMANCE,
  fix: 'Consider using Array.includes() or Set.has() for more efficient lookups.'
}, {
  pattern: /for\s*\([^;]*;\s*[^;]*;\s*[^)]*\)\s*\{\s*[^{]*\.push/,
  message: 'Building an array with repeated .push() in a loop can be inefficient.',
  type: ErrorType.PERFORMANCE,
  fix: 'Consider using Array.map() or defining array with a known size.'
}, {
  pattern: /console\.log/,
  message: 'Debug console.log statements should be removed from production code.',
  type: ErrorType.SUGGESTION,
  fix: 'Remove console.log statements before submission.'
}];

// Advanced analysis for specific data structures and algorithms
var ALGORITHM_PATTERNS = {
  binarySearch: {
    pattern: /while\s*\([^;]*\)\s*\{\s*[^;]*mid[^;]*\(/,
    improvements: ['Check for integer overflow when calculating midpoint. Use mid = left + Math.floor((right - left) / 2) instead of (left + right) / 2', 'Ensure you handle the case when the target is not found', 'Make sure your loop converges by updating left or right appropriately'],
    type: ErrorType.PERFORMANCE
  },
  twoPointers: {
    pattern: /\w+\s*=\s*0[^;]*;\s*\w+\s*=\s*\w+\.length\s*-\s*1/,
    improvements: ['When using two pointers, ensure that the pointers eventually meet or cross', 'Check edge cases like empty arrays or arrays with a single element'],
    type: ErrorType.SUGGESTION
  },
  dynamicProgramming: {
    pattern: /\w+\s*=\s*new\s*Array\([^;]*\);[^;]*\w+\[0\]\s*=/,
    improvements: ['Initialize your DP array with appropriate base cases', 'Ensure your recurrence relation is correct', 'Consider optimizing space complexity by using rolling arrays when possible'],
    type: ErrorType.PERFORMANCE
  }
};

// Analyze the provided code and return an array of issues
function analyzeCode(code) {
  if (!code || typeof code !== 'string' || code.trim() === '') {
    return [{
      message: 'No code to analyze',
      type: ErrorType.WARNING,
      lineNumber: 0
    }];
  }
  var issues = [];
  var lines = code.split('\n');

  // Check for common patterns
  COMMON_PATTERNS.forEach(function (pattern) {
    var matches = code.match(pattern.pattern);
    if (matches) {
      // Find line number for the match
      var lineNumber = 0;
      for (var i = 0; i < lines.length; i++) {
        if (lines[i].match(pattern.pattern)) {
          lineNumber = i + 1;
          break;
        }
      }
      issues.push({
        message: pattern.message,
        type: pattern.type,
        fix: pattern.fix,
        lineNumber: lineNumber,
        codeSnippet: matches[0]
      });
    }
  });

  // Check for algorithm-specific patterns
  Object.entries(ALGORITHM_PATTERNS).forEach(function (_ref) {
    var _ref2 = _slicedToArray(_ref, 2),
      name = _ref2[0],
      _ref2$ = _ref2[1],
      pattern = _ref2$.pattern,
      improvements = _ref2$.improvements,
      type = _ref2$.type;
    var matches = code.match(pattern);
    if (matches) {
      // Find line number for the match
      var lineNumber = 0;
      for (var i = 0; i < lines.length; i++) {
        if (lines[i].match(pattern)) {
          lineNumber = i + 1;
          break;
        }
      }
      issues.push({
        message: "Detected possible ".concat(name, " algorithm. Consider these improvements:"),
        type: type,
        fix: improvements.join('\n'),
        lineNumber: lineNumber,
        codeSnippet: matches[0]
      });
    }
  });

  // Add complexity analysis (simple estimation)
  var complexity = estimateComplexity(code);
  if (complexity) {
    issues.push({
      message: "Estimated time complexity: ".concat(complexity.time),
      type: ErrorType.PERFORMANCE,
      fix: complexity.suggestions.join('\n'),
      lineNumber: 0
    });
  }
  return issues;
}

// Very simple estimation of code complexity
function estimateComplexity(code) {
  var complexity = {
    time: 'O(n)',
    suggestions: []
  };

  // Check for nested loops - O(n²)
  if (/for\s*\([^;]*;\s*[^;]*;\s*[^)]*\)[^{]*\{[^}]*for\s*\([^;]*;\s*[^;]*;\s*[^)]*\)/.test(code)) {
    complexity.time = 'O(n²)';
    complexity.suggestions.push('Your code contains nested loops which result in quadratic time complexity. Consider if this is necessary or if there are more efficient approaches.');
  }

  // Check for recursive calls without memoization
  if (/function\s+\w+[^{]*\{[^}]*\1\s*\([^)]*\)/.test(code) && !code.includes('memo')) {
    complexity.suggestions.push('Your code appears to be recursive without memoization. Consider adding memoization to avoid redundant calculations.');
  }

  // Check for potentially optimizable operations
  if (code.includes('.indexOf') || code.includes('.includes')) {
    complexity.suggestions.push('Consider using a Set or Map for faster lookups instead of array methods like indexOf or includes for large datasets.');
  }
  return complexity;
}

// Function to format analysis results as HTML
function formatAnalysisResults(issues) {
  if (!issues || issues.length === 0) {
    return '<div style="padding: 10px; text-align: center;">No issues found. Great job!</div>';
  }
  var groupedIssues = _defineProperty(_defineProperty(_defineProperty(_defineProperty({}, ErrorType.ERROR, []), ErrorType.WARNING, []), ErrorType.PERFORMANCE, []), ErrorType.SUGGESTION, []);

  // Group issues by type
  issues.forEach(function (issue) {
    if (groupedIssues[issue.type]) {
      groupedIssues[issue.type].push(issue);
    } else {
      groupedIssues[ErrorType.SUGGESTION].push(issue);
    }
  });
  var html = '';

  // Add error count summary
  var totalIssues = issues.length;
  var errorCount = groupedIssues[ErrorType.ERROR].length;
  var warningCount = groupedIssues[ErrorType.WARNING].length;
  var perfCount = groupedIssues[ErrorType.PERFORMANCE].length;
  html += "<div style=\"margin-bottom: 10px; font-size: 13px;\">Found ".concat(totalIssues, " issue").concat(totalIssues !== 1 ? 's' : '');
  if (errorCount > 0) html += ", including ".concat(errorCount, " error").concat(errorCount !== 1 ? 's' : '');
  html += '</div>';

  // Add issues by type
  var _loop = function _loop() {
    var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
      type = _Object$entries$_i[0],
      typeIssues = _Object$entries$_i[1];
    if (typeIssues.length === 0) return 1; // continue
    var typeName;
    var typeColor;
    switch (type) {
      case ErrorType.ERROR:
        typeName = 'Errors';
        typeColor = '#f44336';
        break;
      case ErrorType.WARNING:
        typeName = 'Warnings';
        typeColor = '#ffc107';
        break;
      case ErrorType.PERFORMANCE:
        typeName = 'Performance Issues';
        typeColor = '#2196f3';
        break;
      case ErrorType.SUGGESTION:
        typeName = 'Suggestions';
        typeColor = '#4caf50';
        break;
      default:
        typeName = 'Other Issues';
        typeColor = '#9e9e9e';
    }
    html += "<div style=\"margin-top: 12px;\">\n      <div style=\"font-weight: 500; font-size: 14px; color: ".concat(typeColor, "; margin-bottom: 8px;\">").concat(typeName, "</div>");
    typeIssues.forEach(function (issue) {
      var bgColor;
      var borderColor;
      switch (type) {
        case ErrorType.ERROR:
          bgColor = 'rgba(255, 0, 0, 0.1)';
          borderColor = '#f44336';
          break;
        case ErrorType.WARNING:
          bgColor = 'rgba(255, 255, 0, 0.05)';
          borderColor = '#ffc107';
          break;
        case ErrorType.PERFORMANCE:
          bgColor = 'rgba(0, 0, 255, 0.05)';
          borderColor = '#2196f3';
          break;
        case ErrorType.SUGGESTION:
          bgColor = 'rgba(0, 255, 0, 0.05)';
          borderColor = '#4caf50';
          break;
        default:
          bgColor = 'rgba(100, 100, 100, 0.05)';
          borderColor = '#9e9e9e';
      }
      html += "<div class=\"error-item\" style=\"background: ".concat(bgColor, "; border-left: 3px solid ").concat(borderColor, "; padding: 8px; margin-bottom: 8px; border-radius: 0 4px 4px 0;\">\n        <div style=\"font-weight: 500; font-size: 13px; margin-bottom: 4px;\">").concat(issue.message, "</div>");
      if (issue.lineNumber > 0) {
        html += "<div style=\"font-size: 12px; color: #ddd;\">Line ".concat(issue.lineNumber, "</div>");
      }
      if (issue.codeSnippet) {
        html += "<pre style=\"font-family: monospace; background: rgba(0,0,0,0.2); padding: 6px; border-radius: 3px; font-size: 12px; overflow-x: auto; margin: 6px 0;\">".concat(escapeHtml(issue.codeSnippet), "</pre>");
      }
      if (issue.fix) {
        html += "<div style=\"font-size: 12px; color: #aaa; margin-top: 4px;\">Suggestion: ".concat(issue.fix, "</div>");
      }
      html += "</div>";
    });
    html += "</div>";
  };
  for (var _i = 0, _Object$entries = Object.entries(groupedIssues); _i < _Object$entries.length; _i++) {
    if (_loop()) continue;
  }
  return html;
}

// Helper function to escape HTML
function escapeHtml(unsafe) {
  return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}
/******/ })()
;
//# sourceMappingURL=codeAnalysis.js.map