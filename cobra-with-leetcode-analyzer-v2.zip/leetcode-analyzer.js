// Cobra LeetCode Analyzer Content Script
console.log('[Cobra LeetCode Analyzer] Content script loaded');

// Global variables to track state
let analysisInitialized = false;
let widgetCreated = false;

// Function to inject our analyzer script into the page
const injectAnalyzer = () => {
  console.log('[Cobra LeetCode Analyzer] Injecting analyzer script');
  // Create a new script element
  const script = document.createElement('script');
  // Set the source to our inject.js file
  script.src = chrome.runtime.getURL('leetcode-analyzer-inject.js');
  // Remove the script element after it loads
  script.onload = () => script.remove();
  // Add the script to the page
  (document.head || document.documentElement).appendChild(script);
  
  // Mark as initialized
  analysisInitialized = true;
};

// Wait for LeetCode's app container to be available
const waitForLeetCodeApp = () => {
  const maxAttempts = 15;
  let attempts = 0;

  const checkApp = () => {
    // Check if the app container exists or we've tried too many times
    if (document.getElementById('app') || attempts >= maxAttempts) {
      // Inject our analyzer and setup button listener
      injectAnalyzer();
      setupCobraButtonListener();
    } else {
      // Try again after a short delay
      attempts++;
      setTimeout(checkApp, 500);
    }
  };

  checkApp();
};

// Listen for the purple Cobra button click
function setupCobraButtonListener() {
  // Look for the button repeatedly until found
  const findButtonInterval = setInterval(() => {
    const cobraButton = document.getElementById('cobra-helper-button');
    if (cobraButton) {
      clearInterval(findButtonInterval);
      console.log('[Cobra LeetCode Analyzer] Found Cobra button, adding event listener');
      
      cobraButton.addEventListener('click', toggleAnalyzerWidget);
    }
  }, 1000);
  
  // Timeout after 10 seconds
  setTimeout(() => {
    clearInterval(findButtonInterval);
  }, 10000);
  
  // Also set up event listeners for code changes
  setupEventListeners();
}

// Toggle the analyzer widget visibility
function toggleAnalyzerWidget() {
  console.log('[Cobra LeetCode Analyzer] Toggle widget requested');
  
  // If widget doesn't exist yet, create it
  if (!widgetCreated) {
    initializeUI();
    widgetCreated = true;
  } else {
    // Otherwise toggle visibility
    const widget = document.getElementById('leetcode-analyzer-floating-widget');
    if (widget) {
      if (widget.style.display === 'none') {
        widget.style.display = 'block';
      } else {
        widget.style.display = 'none';
      }
    }
  }
}

// Initialize the UI elements
function initializeUI() {
  // Only create the UI if it doesn't already exist
  if (!document.getElementById('leetcode-analyzer-floating-widget')) {
    const container = document.createElement('div');
    container.id = 'leetcode-analyzer-floating-widget';
    container.className = 'leetcode-analyzer-ui';
    container.innerHTML = `
      <div class="widget-header" id="analyzer-widget-header">
        <h3><div class="analyzer-icon"></div>Code Analyzer</h3>
        <div>
          <button id="analyzer-widget-minimize" class="toggle-button">−</button>
          <button id="analyzer-widget-close" class="close-button">×</button>
        </div>
      </div>
      <div class="widget-content" id="analyzer-widget-content">
        <div class="status-message">Ready to analyze your code...</div>
        <div class="analysis-content">
          <p>Start typing to see analysis...</p>
        </div>
      </div>
    `;
    document.body.appendChild(container);
    
    // Make the widget draggable
    makeWidgetDraggable(container);
    
    // Add event listeners for the widget buttons
    document.getElementById('analyzer-widget-close').addEventListener('click', () => {
      container.style.display = 'none';
    });
    
    document.getElementById('analyzer-widget-minimize').addEventListener('click', function() {
      const widgetContent = document.getElementById('analyzer-widget-content');
      if (widgetContent.style.display === 'none') {
        widgetContent.style.display = 'block';
        this.textContent = '−'; // Minus sign
      } else {
        widgetContent.style.display = 'none';
        this.textContent = '+'; // Plus sign
      }
    });
    
    // Trigger analysis for current code
    triggerInitialAnalysis();
  }
}

// Trigger analysis for current code
function triggerInitialAnalysis() {
  // Dispatch an event to get the current code
  const script = document.createElement('script');
  script.textContent = `
    if (window.findMonacoEditor) {
      const editor = window.findMonacoEditor();
      if (editor) {
        const code = editor.getValue();
        // Get the problem slug from the URL
        const problemSlug = window.location.pathname.split('/')[2];
        
        window.dispatchEvent(new CustomEvent('cobra-trigger-analysis', {
          detail: {
            code: code,
            problemSlug: problemSlug
          }
        }));
      }
    }
  `;
  document.head.appendChild(script);
  script.remove();
}

// Set up event listeners for editor changes
function setupEventListeners() {
  // Listen for code changes from the injected script
  window.addEventListener('cobra-leetcode-editor-changed', function(event) {
    console.log('[Cobra LeetCode Analyzer] Received code change event');
    
    // Only analyze if widget exists and is visible
    const widget = document.getElementById('leetcode-analyzer-floating-widget');
    if (!widget || widget.style.display === 'none') {
      return;
    }
    
    // Extract the code and problem slug from the event
    const code = event.detail.code;
    const problemSlug = event.detail.problemSlug;
    
    // Validate we have what we need
    if (!code) {
      console.error('[Cobra LeetCode Analyzer] No code received');
      return;
    }
    
    if (!problemSlug) {
      console.error('[Cobra LeetCode Analyzer] No problem slug received');
      return;
    }
    
    console.log('[Cobra LeetCode Analyzer] Analyzing code for problem:', problemSlug);
    
    // Trigger the analysis
    analyzeCode(code, problemSlug);
  });
  
  // Listen for initial analysis trigger
  window.addEventListener('cobra-trigger-analysis', function(event) {
    const widget = document.getElementById('leetcode-analyzer-floating-widget');
    if (!widget || widget.style.display === 'none') {
      return;
    }
    
    const code = event.detail.code;
    const problemSlug = event.detail.problemSlug;
    
    if (code && problemSlug) {
      analyzeCode(code, problemSlug);
    }
  });
}

// Make the widget draggable
function makeWidgetDraggable(widget) {
  const header = document.getElementById('analyzer-widget-header');
  if (!header) return;
  
  let offsetX, offsetY, isDragging = false;
  
  header.addEventListener('mousedown', function(e) {
    isDragging = true;
    offsetX = e.clientX - widget.getBoundingClientRect().left;
    offsetY = e.clientY - widget.getBoundingClientRect().top;
    
    // Add a style to indicate dragging
    widget.style.opacity = '0.8';
  });
  
  document.addEventListener('mousemove', function(e) {
    if (!isDragging) return;
    
    widget.style.left = (e.clientX - offsetX) + 'px';
    widget.style.top = (e.clientY - offsetY) + 'px';
    widget.style.right = 'auto';
  });
  
  document.addEventListener('mouseup', function() {
    isDragging = false;
    widget.style.opacity = '1';
  });
}

// Main function to analyze the code
function analyzeCode(code, problemSlug) {
  console.log('[Cobra LeetCode Analyzer] Analyzing code...');
  
  // Get the floating widget
  const floatingWidget = document.getElementById('leetcode-analyzer-floating-widget');
  if (!floatingWidget || floatingWidget.style.display === 'none') {
    return; // Don't continue if widget is hidden
  }
  
  // Update the status message
  const statusMessage = floatingWidget.querySelector('.status-message');
  if (statusMessage) {
    statusMessage.textContent = 'Analyzing your code...';
  }

  // Check if we have the OpenAI API key
  chrome.storage.sync.get(['cobra_openai_key'], function(result) {
    const apiKey = result.cobra_openai_key || localStorage.getItem('cobra_openai_key');
    
    if (!apiKey) {
      console.error('[Cobra LeetCode Analyzer] No OpenAI API key found');
      // Update status message
      if (statusMessage) {
        statusMessage.innerHTML = 'Error: No OpenAI API key found. Go to extension options to set it.';
      }
      return;
    }
    
    // Use the OpenAI API
    analyzeCodeWithOpenAI(code, problemSlug, apiKey)
      .then(results => {
        console.log('[Cobra LeetCode Analyzer] Analysis result:', results);
        displayAnalysisResults(results);
      })
      .catch(error => {
        console.error('[Cobra LeetCode Analyzer] Error analyzing code:', error);
        // Update status message
        if (statusMessage) {
          statusMessage.textContent = `Error analyzing code: ${error.message}`;
        }
      });
  });
}

// Function to call OpenAI's API for code analysis
async function analyzeCodeWithOpenAI(code, problemSlug, openaiKey) {
  // Make the API call to OpenAI
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${openaiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are a code analysis assistant. Analyze the provided code for potential issues, optimizations, and best practices. Be concise and focus on the most important points. When mentioning line numbers, use the format "Line X:".'
        },
        {
          role: 'user',
          content: `Analyze this code for LeetCode problem ${problemSlug}:\n\n${code}`
        }
      ],
      temperature: 0.3
    })
  });

  if (!response.ok) {
    throw new Error('Failed to analyze code');
  }

  const data = await response.json();
  return {
    analysis: data.choices[0].message.content,
    lines: extractLinesFromAnalysis(data.choices[0].message.content)
  };
}

// Extract line numbers mentioned in the analysis
function extractLinesFromAnalysis(analysis) {
  const lines = [];
  // Match "Line X:" pattern
  const lineRegex = /Line (\d+):/gi;
  let match;
  
  // Find all line number references in the analysis
  while ((match = lineRegex.exec(analysis)) !== null) {
    lines.push(parseInt(match[1]));
  }
  
  // Remove duplicate line numbers
  return [...new Set(lines)];
}

// Format the analysis text for better display
function formatAnalysis(text) {
  return text
    // Convert markdown headers
    .replace(/^# (.*)/gm, '<h4 style="margin: 12px 0 8px 0; color: #8A2BE2;">$1</h4>')
    // Convert markdown lists
    .replace(/^- (.*)/gm, '<li>$1</li>')
    // Convert markdown code blocks
    .replace(/```([^`]+)```/g, '<pre style="background-color: #222; padding: 8px; overflow-x: auto; border-radius: 4px; color: #e0e0e0;">$1</pre>')
    // Convert markdown inline code
    .replace(/`([^`]+)`/g, '<code style="background-color: #222; padding: 2px 4px; border-radius: 3px;">$1</code>')
    // Convert markdown bold
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    // Highlight line references
    .replace(/Line (\d+):/g, '<span style="color: #8A2BE2; font-weight: bold;">Line $1:</span>')
    // Convert plain line breaks to HTML
    .replace(/\n/g, '<br>');
}

// Display the analysis results in the UI
function displayAnalysisResults(results) {
  const container = document.getElementById('leetcode-analyzer-floating-widget');
  if (!container) return;

  const analysisContent = container.querySelector('.analysis-content');
  if (!analysisContent) return;

  // Format and display the analysis
  analysisContent.innerHTML = `
    <div class="analysis-text">
      ${formatAnalysis(results.analysis)}
    </div>
  `;

  // Update status message
  const statusMessage = container.querySelector('.status-message');
  if (statusMessage) {
    statusMessage.textContent = 'Analysis complete!';
  }

  // Make sure widget is visible
  container.style.display = 'block';
  const widgetContent = container.querySelector('.widget-content');
  if (widgetContent && widgetContent.style.display === 'none') {
    widgetContent.style.display = 'block';
    const toggleButton = document.getElementById('analyzer-widget-minimize');
    if (toggleButton) {
      toggleButton.textContent = '−'; // Minus sign
    }
  }

  // Highlight the relevant code lines
  highlightCodeLines(results.lines);
}

// Highlight specific lines in the code editor
function highlightCodeLines(lines) {
  const codeLines = document.querySelectorAll('.view-line');
  codeLines.forEach((line, index) => {
    if (lines.includes(index + 1)) {
      line.classList.add('leetcode-analyzer-highlight');
    } else {
      line.classList.remove('leetcode-analyzer-highlight');
    }
  });
}

// Handle LeetCode navigation (it's a SPA)
let currentPath = window.location.pathname;
function checkForNavigation() {
  // Check if we've navigated to a new problem
  if (window.location.pathname !== currentPath) {
    console.log('[Cobra LeetCode Analyzer] Navigation detected - from', currentPath, 'to', window.location.pathname);
    currentPath = window.location.pathname;
    
    // Only reinitialize if we're on a problem page
    if (currentPath.includes('/problems/')) {
      console.log('[Cobra LeetCode Analyzer] On a problem page, reinitializing...');
      // Small delay to ensure the page has loaded
      setTimeout(() => {
        waitForLeetCodeApp();
      }, 1000);
    }
  }
  
  // Continue checking
  setTimeout(checkForNavigation, 1000);
}

// Start navigation monitoring
checkForNavigation();

// Initialize UI when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('[Cobra LeetCode Analyzer] DOM fully loaded');
  
  // Start checking for the LeetCode app container
  waitForLeetCodeApp();
});

// Additional event listener for when window is completely loaded
window.addEventListener('load', function() {
  console.log('[Cobra LeetCode Analyzer] Window fully loaded');
  
  // This is another opportunity to initialize if DOMContentLoaded didn't work
  waitForLeetCodeApp();
}); 