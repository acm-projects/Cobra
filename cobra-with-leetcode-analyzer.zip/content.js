/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/

// Simple content script to verify that the extension is running
console.log("COBRA EXTENSION LOADED");
// Check if we're on LeetCode
var isLeetCodePage = window.location.hostname.includes('leetcode.com');
console.log("Is LeetCode page: ".concat(isLeetCodePage));
// No visible indicator or popups are needed anymore
// The SelectionDetector component will handle everything automatically
// Simple function to show a test suggestion widget
function showTestSuggestion(selection) {
    // Remove any existing widget
    var existingWidget = document.getElementById('cobra-test-widget');
    if (existingWidget) {
        existingWidget.remove();
    }
    // Get position based on selection
    var range = selection.getRangeAt(0);
    var rect = range.getBoundingClientRect();
    // Create widget
    var widget = document.createElement('div');
    widget.id = 'cobra-test-widget';
    widget.style.position = 'absolute';
    widget.style.top = "".concat(window.scrollY + rect.top - 60, "px");
    widget.style.left = "".concat(window.scrollX + rect.left + (rect.width / 2) - 150, "px");
    widget.style.zIndex = '9999999';
    widget.style.width = '300px';
    widget.style.backgroundColor = 'white';
    widget.style.borderRadius = '10px';
    widget.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.12)';
    widget.style.padding = '10px 15px';
    widget.style.fontFamily = "'Inter', 'Segoe UI', Arial, sans-serif";
    widget.style.border = '1px solid rgba(0, 0, 0, 0.05)';
    widget.style.borderTop = '3px solid #3182CE';
    // Add content
    widget.innerHTML = "\n    <div style=\"display: flex; align-items: center; gap: 10px; margin-bottom: 10px;\">\n      <div style=\"width: 28px; height: 28px; border-radius: 50%; background-color: #EBF8FF; color: #3182CE; display: flex; align-items: center; justify-content: center; font-size: 16px;\">\uD83D\uDCA1</div>\n      <div style=\"font-weight: 500; color: #2D3748;\">Consider optimizing this code</div>\n    </div>\n    <div style=\"display: flex; gap: 10px; margin-top: 10px;\">\n      <button id=\"cobra-fix-button\" style=\"flex: 1; padding: 8px 14px; background-color: #3182CE; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;\">Fix this issue</button>\n      <button id=\"cobra-dismiss-button\" style=\"padding: 8px 14px; background-color: white; color: #4A5568; border: 1px solid #E2E8F0; border-radius: 6px; font-weight: 600; cursor: pointer;\">Ignore</button>\n    </div>\n  ";
    // Add to page
    document.body.appendChild(widget);
    // Add dismiss handler
    var dismissButton = widget.querySelector('#cobra-dismiss-button');
    if (dismissButton) {
        dismissButton.addEventListener('click', function () {
            widget.remove();
        });
    }
    // Click outside to dismiss
    document.addEventListener('mousedown', function (event) {
        if (widget && !widget.contains(event.target)) {
            widget.remove();
        }
    }, { once: true });
}
// Only initialize on LeetCode problem pages
if (isLeetCodePage && window.location.pathname.includes('/problems/')) {
    console.log("COBRA: On LeetCode problem page, selection detector will be active");
    // Direct DOM-based fallback for selection detection
    document.addEventListener('mouseup', function () {
        setTimeout(function () {
            var selection = window.getSelection();
            if (selection && !selection.isCollapsed) {
                var text = selection.toString().trim();
                if (text.length > 0) {
                    console.log("COBRA: Text selected:", text);
                    // Check if we're in the code editor area
                    var range = selection.getRangeAt(0);
                    var container = range.commonAncestorContainer;
                    var isInEditor = (container.nodeType === Node.ELEMENT_NODE &&
                        (container.closest('.monaco-editor') ||
                            container.closest('.view-lines'))) ||
                        (container.nodeType === Node.TEXT_NODE &&
                            container.parentElement &&
                            (container.parentElement.closest('.monaco-editor') ||
                                container.parentElement.closest('.view-lines')));
                    if (isInEditor) {
                        console.log("COBRA: Selection is within code editor");
                        showTestSuggestion(selection);
                    }
                    else {
                        console.log("COBRA: Selection is not within code editor");
                    }
                }
            }
        }, 100);
    });
}
else {
    console.log("COBRA: Not on a LeetCode problem page");
}

/******/ })()
;
//# sourceMappingURL=content.js.map