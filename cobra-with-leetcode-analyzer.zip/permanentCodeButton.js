/******/ (() => { // webpackBootstrap
/*!************************************!*\
  !*** ./src/permanentCodeButton.js ***!
  \************************************/
// Permanent Cobra code button
// This script adds a permanent button next to the "</> Code" part of the editor

(function () {
  'use strict';

  console.log('Permanent Cobra Button: Script loaded');

  // Create and position the permanent button
  function createPermanentButton() {
    console.log('Creating permanent Cobra button');

    // Remove existing button if any
    var existingButton = document.getElementById('cobra-permanent-button');
    if (existingButton) {
      existingButton.remove();
    }

    // Create the button element
    var button = document.createElement('div');
    button.id = 'cobra-permanent-button';
    button.className = 'cobra-permanent-button';
    button.title = 'Cobra Code Helper';

    // Use the icon image
    var iconImg = document.createElement('img');
    iconImg.src = chrome.runtime.getURL('images/icon.png');
    iconImg.alt = 'Cobra';
    iconImg.style.width = '24px';
    iconImg.style.height = '24px';
    iconImg.style.objectFit = 'contain';
    button.appendChild(iconImg);

    // Style the button
    button.style.display = 'flex';
    button.style.alignItems = 'center';
    button.style.justifyContent = 'center';
    button.style.width = '32px';
    button.style.height = '32px';
    button.style.borderRadius = '6px';
    button.style.marginLeft = '8px';
    button.style.cursor = 'pointer';
    button.style.backgroundColor = 'transparent';
    button.style.transition = 'background-color 0.2s ease';

    // Add hover effect
    button.addEventListener('mouseover', function () {
      button.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
    });
    button.addEventListener('mouseout', function () {
      button.style.backgroundColor = 'transparent';
    });

    // Add click handler for the button
    button.addEventListener('click', function (e) {
      console.log('Permanent Cobra button clicked');
      e.stopPropagation();
      showHelperWidget();
    });

    // Find the code header element and insert the button
    var codeHeaders = findCodeHeader();
    if (codeHeaders && codeHeaders.length > 0) {
      var codeHeader = codeHeaders[0];
      codeHeader.appendChild(button);
      console.log('Permanent button added to code header');
    } else {
      // Fallback: Add to document body in a fixed position if header not found
      document.body.appendChild(button);
      button.style.position = 'fixed';
      button.style.top = '10px';
      button.style.left = '120px'; // Position it approximately where the header would be
      button.style.zIndex = '10000';
      console.log('Code header not found, button added in fixed position');
    }
    return button;
  }

  // Helper function to find the "</> Code" header element
  function findCodeHeader() {
    // Try different selectors that might match the code header
    // This is necessary because different editors may have different structures
    var selectors = [
    // Common editor header selectors
    '.editor-header', '.code-header', '.monaco-editor-top', '.editor-titlebar', '.editor-title-section',
    // Selectors that might contain "Code" text
    'h1:contains("Code")', 'div:contains("</> Code")',
    // Generic title selectors
    '.title-container', '.editor-container > header', '.header-content'];
    for (var _i = 0, _selectors = selectors; _i < _selectors.length; _i++) {
      var selector = _selectors[_i];
      var elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        console.log("Found code header with selector: ".concat(selector));
        return elements;
      }
    }

    // If no selectors match, look for elements containing the text "</> Code"
    var allElements = document.querySelectorAll('div, header, h1, h2, h3');
    var codeHeaders = Array.from(allElements).filter(function (el) {
      return el.textContent && el.textContent.includes('</> Code');
    });
    if (codeHeaders.length > 0) {
      console.log('Found code header with text "</> Code"');
      return codeHeaders;
    }
    console.log('Code header not found');
    return null;
  }

  // Show the helper widget
  function showHelperWidget() {
    console.log('Showing helper widget');

    // Remove existing widget if any
    hideHelperWidget();

    // Create the widget
    var widget = document.createElement('div');
    widget.id = 'cobra-helper-widget';
    document.body.appendChild(widget);

    // Style the widget
    widget.style.position = 'fixed';
    widget.style.top = '50px';
    widget.style.right = '20px';
    widget.style.width = '300px';
    widget.style.backgroundColor = 'white';
    widget.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.12)';
    widget.style.borderRadius = '10px';
    widget.style.zIndex = '9999';
    widget.style.fontFamily = "'Inter', 'Segoe UI', Arial, sans-serif";
    widget.style.padding = '15px';
    widget.style.border = '1px solid rgba(0, 0, 0, 0.05)';
    widget.style.borderTop = '3px solid #3182CE';

    // Add content to the widget
    widget.innerHTML = "\n      <div style=\"display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;\">\n        <div style=\"font-weight: 600; color: #2D3748; font-size: 16px;\">Cobra Code Helper</div>\n        <button id=\"close-widget\" style=\"background: none; border: none; cursor: pointer; font-size: 20px; color: #718096;\">\xD7</button>\n      </div>\n      <div style=\"margin-bottom: 15px; color: #4A5568; font-size: 14px;\">\n        How can I help you with your code?\n      </div>\n      <div style=\"display: flex; gap: 10px;\">\n        <button id=\"cobra-check-button\" style=\"flex: 1; padding: 8px 14px; background-color: #3182CE; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px;\">Check Code</button>\n        <button id=\"cobra-docs-button\" style=\"padding: 8px 14px; background-color: white; color: #4A5568; border: 1px solid #E2E8F0; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 14px;\">View Docs</button>\n      </div>\n    ";

    // Add event listeners
    setTimeout(function () {
      document.getElementById('close-widget').addEventListener('click', function () {
        hideHelperWidget();
      });
      document.getElementById('cobra-check-button').addEventListener('click', function () {
        console.log('Check button clicked');
        // Implement your code check functionality here
        alert('Checking your code...');
      });
      document.getElementById('cobra-docs-button').addEventListener('click', function () {
        console.log('Docs button clicked');
        // Implement your documentation functionality here
        alert('Opening documentation...');
      });
    }, 0);

    // Close widget when clicking outside
    document.addEventListener('mousedown', function handleClickOutside(event) {
      if (widget && !widget.contains(event.target) && event.target.id !== 'cobra-permanent-button' && !event.target.closest('#cobra-permanent-button')) {
        hideHelperWidget();
        document.removeEventListener('mousedown', handleClickOutside);
      }
    });
  }

  // Hide the helper widget
  function hideHelperWidget() {
    var widget = document.getElementById('cobra-helper-widget');
    if (widget) {
      widget.remove();
    }
  }

  // Initialize the permanent button
  function initialize() {
    console.log('Initializing permanent Cobra button');

    // Wait a bit for the page to fully load
    setTimeout(function () {
      createPermanentButton();

      // Set up a mutation observer to handle dynamic UI changes
      var observer = new MutationObserver(function (mutations) {
        // Check if our button is still in the DOM
        var button = document.getElementById('cobra-permanent-button');
        if (!button) {
          console.log('Button removed from DOM, recreating');
          createPermanentButton();
        }
      });

      // Start observing document body for changes
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }, 1000);
  }

  // Run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
})();
/******/ })()
;
//# sourceMappingURL=permanentCodeButton.js.map