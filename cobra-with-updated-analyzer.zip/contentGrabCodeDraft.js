/******/ (() => { // webpackBootstrap
/*!*************************************!*\
  !*** ./src/contentGrabCodeDraft.js ***!
  \*************************************/
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t["return"] || t["return"](); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
console.log("Attempting to log changes to code...");
var target = "#editor > div.flex.flex-1.flex-col.overflow-hidden.pb-2 > div.flex-1.overflow-hidden > div > div > div.overflow-guard > div.monaco-scrollable-element.editor-scrollable.vs-dark > div.lines-content.monaco-editor-background > div.view-lines.monaco-mouse-cursor-text";
var config = {
  childList: true,
  subtree: true,
  characterData: true
};
var documentObserver = new MutationObserver(function (mutations, obs) {
  if (document.querySelector(target)) {
    var codeObserver = new MutationObserver(function (codeMutations, codeObs) {
      //console.log("something changed");
      var _iterator = _createForOfIteratorHelper(codeMutations),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var mutation = _step.value;
          //console.log(mutation);
          console.log(mutation.addedNodes[0].innerText);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      var userCode = "";
      var n = 1;
      var lineObjects = [];
      var _iterator2 = _createForOfIteratorHelper(document.querySelector(target).childNodes),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var line = _step2.value;
          lineObjects.push(line);
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
      lineObjects = lineObjects.sort(function (a, b) {
        return a.getBoundingClientRect().top - b.getBoundingClientRect().top;
      });
      console.log(lineObjects);
      var _iterator3 = _createForOfIteratorHelper(lineObjects),
        _step3;
      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var lineObj = _step3.value;
          userCode += "line ".concat(n, ": ") + lineObj.innerText + "\n";
          n++;
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
      chrome.runtime.sendMessage({
        type: "sendDraft",
        data: userCode
      });
    });
    codeObserver.observe(document.querySelector(target), config);
    obs.disconnect();
  } else {
    console.log("waiting for code frame to load in...");
  }
});
documentObserver.observe(document, {
  childList: true,
  subtree: true
});
/******/ })()
;
//# sourceMappingURL=contentGrabCodeDraft.js.map