// Test script for our loading components
console.log("Components built successfully");

// To verify in browser:
document.addEventListener('DOMContentLoaded', () => {
  const testDiv = document.createElement('div');
  testDiv.innerHTML = `
    <h1>Component Test</h1>
    <div id="test-container"></div>
  `;
  document.body.appendChild(testDiv);
  
  console.log("Test page loaded");
}); 